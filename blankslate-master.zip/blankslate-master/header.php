<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>"/>
	<meta name="viewport" content="width=device-width"/>
	<?php wp_head(); ?>
	<!--[if lte IE 9]>
	<script src="<?php bloginfo('template_url');?>/js/html5shiv/html5shiv.min.js"></script>
	<script src="<?php bloginfo('template_url');?>/js/html5shiv/html5shiv-print.min.js"></script>
	<script src="<?php bloginfo('template_url');?>/js/respond/respond.min.js"></script>
	<script src="<?php bloginfo('template_url');?>/js/respond/respond.matchmedia.addListener.minjs"></script>
<![endif]-->
	<!--[if lte IE 8]>
<script type="text/javascript">
	alert('Thank you for visiting <?php bloginfo('title');?>, it appears your view our website on an old, out of date browser this may affect your ability to view and navigate our website. For the best possible viewing experience, please install a more up to date web browser.');
</script>
<![endif]-->
</head>

<body <?php body_class(); ?> style="overflow-x:hidden;">
	<div id="page-preload" style="position: absolute; display: block; width:100%; height: 100%; z-index: 999999; background-color:#ffffff; pointer-events:none;" class="animated fadeOut"></div>
	<div id="wrapper" class="hfeed">
		<section id="header" role="banner" class="navbar fixed-top navbar-expand-lg navbar-dark scrolling-navbar">
			<div class="row">
				<section id="branding" class="col-lg-4 col-md-10 col-sm-10 col-10">
					<a href="<?php bloginfo('url');?>" title="home"><img src="<?php bloginfo('template_url');?>/img/template/logo-placer.png" alt="<?php bloginfo('description');?>" /></a>
				</section>
				<nav id="menu" class="col-md-8 collapse navbar-collapse" role="navigation">
					<div id="search">
						<?php get_search_form(); ?>
					</div>
					<ul id="main-menu" class="main-navigation navbar-nav ml-auto">

						<?php wp_nav_menu( array( 'theme_location' => 'main-menu', 'container' => '', 'items_wrap' => '%3$s' ) ); ?>
						<!--<li class="nav-item"><a href="#" id="head-login" class="nav-link"><i class="fa fa-lock" aria-hidden="true"></i> User Login</a></li>
	<li class="nav-item"><a href="#" id="head-search" class="nav-link"><i class="fa fa-search" aria-hidden="true"></i></a></li>-->

					</ul>
				</nav>
				<div id="mobile-toggle" class="col-2">
					<a href="#"><i class="fa fa-bars"></i></a>
				</div>
			</div>
		</section>
		<section id="mobile-menu" class="mobile-nav toggle-closed">
			<div id="mobile-menu-top" class="row">
				<div class="col-10">

				</div>
				<div id="mobile-menu-close" class="col-2">
					<a href="#"><i class="fa fa-close"></i></a>
				</div>
			</div>
			<nav id="mobile-nav-menu" role="navigation">
				<div id="search">
					<?php get_search_form(); ?>
				</div>
				<ul id="mobile-nav" class="main-navigation navbar-nav ml-auto">

					<?php wp_nav_menu( array( 'theme_location' => 'mobile-nav', 'container' => '', 'items_wrap' => '%3$s' ) ); ?>
					<!--<li class="nav-item"><a href="#" id="head-login" class="nav-link"><i class="fa fa-lock" aria-hidden="true"></i> User Login</a></li>
	<li class="nav-item"><a href="#" id="head-search" class="nav-link"><i class="fa fa-search" aria-hidden="true"></i></a></li>-->

				</ul>
			</nav>
		</section>
		<div id="content">