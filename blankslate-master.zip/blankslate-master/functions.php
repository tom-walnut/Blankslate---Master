<?php
// replace "bigfoot" with project name
add_action( 'after_setup_theme', 'bigfoot_setup' );
function bigfoot_setup()
{
// Bigfoot Updater Includes    

    
load_theme_textdomain( 'bigfoot', get_template_directory() . '/languages' );
add_theme_support( 'title-tag' );
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'post-thumbnails' );
global $content_width;
if ( ! isset( $content_width ) ) $content_width = 640;
register_nav_menus(
array( 
	'main-menu' => __( 'Main Menu', 'bigfoot'), 'theme_location' => 'Head Navigation',
	'footer-nav' => __('Footer Navigation', 'bigfoot'), 'theme_location' => 'Footer Top',
	'mobile-nav' => __('Mobile Navigation', 'bigfoot'), 'theme_location' => 'Mobile Hamburger Menu',
	'account-quicklinks' => __('My Account Quick Links', 'bigfoot'), 'theme_location' => 'My Account Dropdown'
	)	
);
}
// bootstrap classes on menu items
function bigfoot_menu_classes($classes, $item, $args) {
  if($args->theme_location == 'main-menu') {
    $classes[] = 'nav-item';
  }
  return $classes;
}
add_filter('nav_menu_css_class','bigfoot_menu_classes',1,3);

function bigfoot_add_link_atts($atts) {
  $atts['class'] = "nav-link";
  return $atts;
}
add_filter( 'nav_menu_link_attributes', 'bigfoot_add_link_atts');

add_action( 'wp_enqueue_scripts', 'bigfoot_load_scripts' );
function bigfoot_load_scripts()
{
// style.css
wp_enqueue_style('style', get_stylesheet_uri(), array(), null, 'all');
// smart menu
wp_enqueue_style('smartmenu', get_template_directory_uri() . '/js/jquery-nav/src/css/sm-core-css.css', array(), null, 'all');
// main styles
wp_enqueue_style('main', get_template_directory_uri() . '/css/main.css', array(), null, 'all');
// deregister original jquery
wp_deregister_script('jquery');
// Queue latest version of jQuery
wp_enqueue_script( 'jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js', array(), '3xx', true);
// Queue Bootstrap
wp_enqueue_script('bootstrapBundle', get_template_directory_uri() . '/js/bootstrap/bootstrap.bundle.min.js', array('jquery'), '4.1.1' , true);
wp_enqueue_script('bootstrap', get_template_directory_uri() . '/js/bootstrap/bootstrap.min.js', array('jquery'), '4.1.1', true);
// Queue Slick
wp_enqueue_script('slick', get_template_directory_uri() . '/js/slick/slick.min.js', array('jquery'), '1.0', true);
// smart menu
wp_enqueue_script('smartmenus', get_template_directory_uri() . '/js/smartmenus/jquery.smartmenus.js', array('jquery'), '1.0', true);
// Lightbox
wp_enqueue_script('lightbox', get_template_directory_uri() . '/js/lightbox/lightbox.js', array('jquery'), '1.0', true);
// waypoints
wp_enqueue_script('waypoints', get_template_directory_uri() . '/js/waypoints.min.js', array('jquery'), '1.0' , true);
// masonry
wp_enqueue_script('masonry', get_template_directory_uri() . '/js/masonry.js', array('jquery'), '4.0' , true);
// main website js file
wp_enqueue_script('main', get_template_directory_uri() . '/js/main.js', array('jquery'), '1.0' , true);
}

add_action( 'comment_form_before', 'bigfoot_enqueue_comment_reply_script' );
function bigfoot_enqueue_comment_reply_script()
{
if ( get_option( 'thread_comments' ) ) { wp_enqueue_script( 'comment-reply' ); }
}
add_filter( 'the_title', 'bigfoot_title' );
function bigfoot_title( $title ) {
if ( $title == '' ) {
return '&rarr;';
} else {
return $title;
}
}
add_filter( 'wp_title', 'bigfoot_filter_wp_title' );
function bigfoot_filter_wp_title( $title )
{
return $title . esc_attr( get_bloginfo( 'name' ) );
}
add_action( 'widgets_init', 'bigfoot_widgets_init' );
function bigfoot_widgets_init()
{
register_sidebar( array (
'name' => __( 'Sidebar Widget Area', 'bigfoot' ),
'id' => 'primary-widget-area',
'before_widget' => '<li id="%1$s" class="widget-container %2$s col-md-12">',
'after_widget' => "</li>",
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );
register_sidebar( array (
'name' => __( 'Footer Block 1', 'bigfoot' ),
'id' => 'footer-block-1',
'before_widget' => '<div>',
'after_widget' => "</div>",
'before_title' => '<h3 class="footer-box-title %2$s">',
'after_title' => '</h3>',
) );
register_sidebar( array (
'name' => __( 'Footer Block 2', 'bigfoot' ),
'id' => 'footer-block-2',
'before_widget' => '<div>',
'after_widget' => "</div>",
'before_title' => '<h3 class="footer-box-title %2$s">',
'after_title' => '</h3>',
) );
register_sidebar( array (
'name' => __( 'Footer Block 3', 'bigfoot' ),
'id' => 'footer-block-3',
'before_widget' => '<div>',
'after_widget' => "</div>",
'before_title' => '<h3 class="footer-box-title %2$s">',
'after_title' => '</h3>',
) );
register_sidebar( array (
'name' => __( 'Footer Block 4', 'bigfoot' ),
'id' => 'footer-block-4',
'before_widget' => '<div>',
'after_widget' => "</div>",
'before_title' => '<h3 class="footer-box-title %2$s">',
'after_title' => '</h3>',
) );
register_sidebar( array (
'name' => __( 'Footer Top Nav', 'bigfoot' ),
'id' => 'footer-nav',
'before_widget' => '<div>',
'after_widget' => "</div>",
'before_title' => '<h3 class="footer-box-title %2$s">',
'after_title' => '</h3>',
) );
register_sidebar( array (
'name' => __( 'Footer Top Block', 'bigfoot' ),
'id' => 'footer-block',
'before_widget' => '<div>',
'after_widget' => "</div>",
'before_title' => '<h3 class="footer-top-title %2$s">',
'after_title' => '</h3>',
) );
	
// woocommerce shop sidebar check
if(class_exists('woocommerce')) {
	register_sidebar( array (
		'name' => __( 'Shop Sidebar', 'bigfoot' ),
		'id' => 'shop-widget-area',
		'before_widget' => '<li id="%1$s" class="widget-container %2$s col-md-12">',
		'after_widget' => "</li>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	}
}
// Custom search form for HTML 5
function html5_search_form( $form ) {
   $form = '<form role="search" method="get" id="searchform" action="' . home_url( '/' ) . '" >
  <div class="input-group">
  		<input type="text" class="form-control" placeholder="Search..." aria-label="Search Website" value="' . get_search_query() . '" name="s" id="s">
  <div class="input-group-append">
    <button id="searchsubmit" class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
  </div>
</div>
    </form>';
	

    return $form;
}
add_filter( 'get_search_form', 'html5_search_form' );
// Add new fields in general
$new_general_setting = new new_general_setting();
class new_general_setting {
    function new_general_setting( ) {
        add_filter( 'admin_init' , array( &$this , 'register_fields' ) );
    }
    function register_fields() {
        register_setting( 'general', 'footer_statement', 'esc_attr' );
        add_settings_field('footer_statement', '<label for="footer_statement">'.__('Footer Statement' , 'footer_statement' ).'</label>' , array(&$this, 'fields_html') , 'general' );
		register_setting( 'general', 'website_contact_number', 'esc_attr' );
        add_settings_field('website_contact_number', '<label for="website_contact_number">'.__('Contact Number' , 'website_contact_number' ).'</label>' , array(&$this, 'contact_num_field_html') , 'general' );
		register_setting( 'general', 'website_contact_email', 'esc_attr' );
        add_settings_field('website_contact_email', '<label for="website_contact_email">'.__('Contact email' , 'website_contact_email' ).'</label>' , array(&$this, 'contact_email_field_html') , 'general' );
    }
    function fields_html() {
        $value = get_option( 'footer_statement', '' );
        echo '<textarea id="footer_statement" name="footer_statement" class="regular-text" placeholder="Footer Statement">' . $value . '</textarea><br><p class="description"> This statement appears underneath the footer &copy; area <br> To display this information on your page use the getOption shortcode - [getOption option="footer_statement"]</p>';
		 
    }
	function contact_num_field_html() {
	$value = get_option( 'website_contact_number', '' );
        echo '<input type="text" id="website_contact_number" name="website_contact_number" class="regular-text" value="' . $value . '"  /><br><p class="description"> This contact number will be displayed on the website where applicable. <br> To display this information on your page use the getOption shortcode - [getOption option="website_contact_number"] </p>';	
	}
	function contact_email_field_html() {
	$value = get_option( 'website_contact_email', '' );
        echo '<input type="email" id="website_contact_email" name="website_contact_email" class="regular-text" value="' . $value . '"  /><br><p class="description"> This contact email will be displayed on the website where applicable <br> To display this information on your page use the getOption shortcode - [getOption option="website_contact_email"] </p>';	
	}
}
// Move this new general setting up below tagline
add_action( 'admin_head-options-general.php', function()
{
    echo '<style>#wpbody .wrap form{display:none}</style>';
});
add_action( 'admin_footer-options-general.php', function()
{
    ?>
    <script type="text/javascript">
    jQuery(document).ready( function($) 
    {
        var fstatement = $("label[for='footer_statement']").parent().parent(); // Our setting field
        var blogdesc = $("label[for='blogdescription']").parent().parent(); // WordPress setting field
		var contactphone = $("label[for='website_contact_number']").parent().parent(); // Our setting field
		var contactemail = $("label[for='website_contact_email']").parent().parent(); // Our setting field
        var email = $("label[for='new_admin_email']").parent().parent(); // WordPress setting field
        fstatement.insertAfter(blogdesc);
		contactphone.insertBefore(email);
		contactemail.insertBefore(email);
		$('#wpbody .wrap form').fadeIn('slow');
    });
    </script>
    <?php
});
// display option shortcode
// usage: [getOption option="OPTION"]
// replace @ in email strings with <i class="fa fa-at"></i>
function handle_option_shortcode($option) {

extract(shortcode_atts( array(
'option' => 'option',
), $option));

$opt = get_option($option);

if(strpos('@', $opt)) {
$opt = str_replace('@', '<i class="fa fa-at"></i>', $opt);
} else {
// dont change opt
}

return $opt;

}
add_shortcode('getOption', 'handle_option_shortcode');
// Remove admin bar for non editors
add_action('after_setup_theme', 'remove_admin_bar');

function remove_admin_bar() {
if (!current_user_can('manage_options') && !is_admin()) {
  show_admin_bar(false);
	}
}
function bigfoot_custom_pings( $comment )
{
$GLOBALS['comment'] = $comment;
?>
<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>"><?php echo comment_author_link(); ?></li>
<?php 
}
add_filter( 'get_comments_number', 'bigfoot_comments_number' );
function bigfoot_comments_number( $count )
{
if ( !is_admin() ) {
global $id;
$comments_by_type = &separate_comments( get_comments( 'status=approve&post_id=' . $id ) );
return count( $comments_by_type['comment'] );
} else {
return $count;
}
}
// Bootstrap comment form

function bs_comment_form() {
$fields =  array(
 
  'author' =>
    '<p class="comment-form-author"><div class="form-group"><label for="author">' . __( 'Name', 'domainreference' ) . '</label> ' .
    ( $req ? '<span class="required">*</span>' : '' ) .
    '<input id="author" class="form-control" name="author" placeholder="Your Name" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
    '" ' . $aria_req . ' /></div></p>',
 
  'email' =>
    '<p class="comment-form-email"><div class="form-group"><label for="email">' . __( 'Email', 'domainreference' ) . '</label> ' .
    ( $req ? '<span class="required">*</span>' : '' ) .
    '<input id="email" name="email" class="form-control" placeholder="Your Email Address" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
    '" ' . $aria_req . ' /></div></p>',
 
  'url' =>
    '<p class="comment-form-url"><div class="form-group"><label for="url">' . __( 'Website', 'domainreference' ) . '</label>' .
    '<input id="url" name="url" class="form-control" type="text" placeholder="Your Website" value="' . esc_attr( $commenter['comment_author_url'] ) .
    '"   /></p>',
);
    $comments_args = array(
		
		'class_submit' => 'btn btn-primary submit',
 
        // change "Leave a Reply" to "Comment"
        'title_reply'=>'Discuss this post ?',
        'fields' => apply_filters( 'comment_form_default_fields', $fields ),
        'comment_field' =>  '<p class="comment-form-comment"><div class="form-group"><label for="comment">' . _x( 'Comment', 'noun' ) .
            '</label><textarea id="comment" name="comment" class="form-control" placeholder="Type Your Comment.." rows="8" aria-required="true">' .
            '</textarea></div></p>',
             'comment_notes_after' => ' ');
	
	return comment_form($comments_args);
}

//breadcrumbs
add_theme_support( 'yoast-seo-breadcrumbs' );


// Remove version strings from static JS and CSS
function bf_remove_wp_ver_css_js( $src ) {
    if ( strpos( $src, 'ver=' . get_bloginfo( 'version' ) ) )
        $src = remove_query_arg( 'ver', $src );
    return $src;
}
add_filter( 'style_loader_src', 'bf_remove_wp_ver_css_js', 9999 );
add_filter( 'script_loader_src', 'bf_remove_wp_ver_css_js', 9999 );