<?php get_header(); ?>
<section id="content" role="main">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

	<?php the_content(); ?>

</section>
<?php endwhile; endif; ?>

<?php get_footer(); ?>