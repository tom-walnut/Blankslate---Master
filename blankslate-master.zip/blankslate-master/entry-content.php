<section class="entry-content">
	<?php the_content(); ?>
	<div class="entry-links">
		<?php wp_link_pages(); ?>
	</div>
</section>