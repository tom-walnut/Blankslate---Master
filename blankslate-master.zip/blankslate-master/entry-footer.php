<footer class="entry-footer">
	<div class="entry-meta-tags">
		<?php the_tags('<i class="fa fa-tags" aria-hidden="true"></i>&nbsp; Tags:&nbsp;', ',&nbsp;', '&nbsp;'); ?>
	</div>

</footer>