// JavaScript Document
jQuery(document).ready(function ($) {
	'use strict';
	
	// get window width.
	var ss = $(window).width();

	// Navigation and Sticky nav
	// Sticky class added to mobile-menu to fix admin bar.

	$(window).scroll(function () {
		if ($(this).scrollTop() > 150) {
			$('#header').addClass('sticky');
			$('#header').addClass('animated slideInDown');
			$('#mobile-menu').addClass('sticky');
		} else {
			$('#header').removeClass('sticky');
			$('#header').removeClass('animated slideInDown');
			$('#mobile-menu').removeClass('sticky');
		}
	});

    // Mobile nav toggle event
	$('#mobile-toggle a').click(function(e) {
		e.preventDefault();
		if($('#mobile-menu').hasClass('toggle-closed')) {
			$('#mobile-menu').addClass('toggle-open animated slideInRight');
			$('#mobile-menu').removeClass('toggle-closed slideOutRight');
			
		} else {
			$('#mobile-menu').removeClass('toggle-open slideInRight');
			$('#mobile-menu').addClass('toggle-closed animated slideOutRight');
			
		}
	});
	// mobile menu close button
	$('#mobile-menu-close a').click(function(e) {
		e.preventDefault();
			$('#mobile-menu').removeClass('toggle-open slideInRight');
			$('#mobile-menu').addClass('toggle-closed animated slideOutRight');
			
		
	});

    // Default Smart Menu
    $('#main-menu').smartmenus();
    $('#mobile-nav').smartmenus();
    
	//console.log('init slick');
	// Slick Carousels Example
	// 
	//$('.sow-testimonials').slick({
//		lazyLoad: 'ondemand',
//		dots: true,
//		arrows:true,
//		autoplay:true,
//		centerMode:true,
//		slidesToShow: 2,
//		centerPadding: '-50px',
//		prevArrow:'<button type="button" class="slick-prev"><i class="fa fa-chevron-right"></i></button>',
//		nextArrow:'<button type="button" class="slick-next"><i class="fa fa-chevron-right"></i></button>',
//		responsive: [{
//			breakpoint: 768,
//			settings: {
//				arrows: false,
//				centerMode: true,
//				slidesToShow: 1
//			}
//		}, {
//			breakpoint: 480,
//			settings: {
//				arrows: false,
//				centerMode: true,
//				slidesToShow: 1
//			}
//		}]
//	});
    
    console.log('js loaded..');

});